# GTSRB YOLOv8 — Chạy local với Anaconda

## Cấu trúc thư mục

```
gtsrb_yolo/
├── train.py          ← script chính
├── predict.py        ← chạy inference sau khi train
├── README.md
├── data/
│   └── gtsrb-german-traffic-sign/   ← giải nén dataset vào đây
│       ├── Train.csv
│       ├── Test.csv
│       └── Train/
│           ├── 0/
│           ├── 1/
│           └── ...
├── dataset/          ← tự tạo sau khi convert (bỏ qua)
├── gtsrb.yaml        ← tự tạo (bỏ qua)
└── runs/             ← kết quả train & predict (bỏ qua)
```

---

## Setup môi trường

```bash
# 1. Tạo conda environment
conda create -n gtsrb python=3.10 -y
conda activate gtsrb

# 2. Cài PyTorch (chọn 1 trong 2)
# Có GPU NVIDIA:
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
# Không có GPU:
pip install torch torchvision

# 3. Cài thư viện còn lại
pip install ultralytics scikit-learn pillow pandas pyyaml
```

---

## Download dataset

1. Vào https://www.kaggle.com/datasets/meowmeowmeowmeowmeow/gtsrb-german-traffic-sign
2. Download → giải nén vào `data/gtsrb-german-traffic-sign/`

---

## Chạy

```bash
# Train (convert + train tự động)
python train.py

# Sau khi train xong, chạy inference
python predict.py --source ./dataset/images/val

# Inference trên 1 ảnh cụ thể
python predict.py --source ./my_image.jpg --conf 0.4

# Hiện ảnh ngay (cần GUI/màn hình)
python predict.py --source ./my_image.jpg --show
```

---

## Tuỳ chỉnh trong train.py

| Biến | Mặc định | Ghi chú |
|------|----------|---------|
| `MODEL_SIZE` | `"s"` | n / s / m / l / x |
| `EPOCHS` | `30` | Tăng lên 50–100 để accuracy cao hơn |
| `BATCH` | `16` | Giảm xuống 8 nếu out of memory |
| `device` | `0` | Đổi thành `"cpu"` nếu không có GPU |

---

## Kết quả sau train

- Weights tốt nhất: `./runs/gtsrb_v1/weights/best.pt`
- Metrics & charts: `./runs/gtsrb_v1/`
- Ảnh predict: `./runs/predict/`
