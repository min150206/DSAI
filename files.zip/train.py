"""
GTSRB → YOLOv8 Training Script
Chạy: python train.py
"""

import os
import pandas as pd
from PIL import Image
from sklearn.model_selection import train_test_split
from ultralytics import YOLO
import yaml

# ─── CẤU HÌNH ────────────────────────────────────────────────────────────────
SRC_ROOT   = "./data/gtsrb-german-traffic-sign"   # thư mục chứa dataset gốc
OUT        = "./dataset"                           # thư mục output sau convert
YAML_PATH  = "./gtsrb.yaml"
MODEL_SIZE = "s"                                   # n / s / m / l / x
EPOCHS     = 30
BATCH      = 16                                    # giảm xuống 8 nếu RAM GPU < 6GB
IMGSZ      = 640
# ─────────────────────────────────────────────────────────────────────────────

CLASS_NAMES = [
    "Speed limit (20)",     "Speed limit (30)",     "Speed limit (50)",
    "Speed limit (60)",     "Speed limit (70)",     "Speed limit (80)",
    "End speed limit (80)", "Speed limit (100)",    "Speed limit (120)",
    "No passing",           "No passing >3.5t",     "Right-of-way",
    "Priority road",        "Yield",                "Stop",
    "No vehicles",          "No vehicles >3.5t",    "No entry",
    "General caution",      "Dangerous curve left", "Dangerous curve right",
    "Double curve",         "Bumpy road",           "Slippery road",
    "Road narrows",         "Road work",            "Traffic signals",
    "Pedestrians",          "Children crossing",    "Bicycles crossing",
    "Beware ice/snow",      "Wild animals",         "End restrictions",
    "Turn right ahead",     "Turn left ahead",      "Ahead only",
    "Straight or right",    "Straight or left",     "Keep right",
    "Keep left",            "Roundabout",           "End no passing",
    "End no passing >3.5t",
]


def convert_dataset():
    """Convert GTSRB CSV annotations sang YOLO format."""
    csv_path = os.path.join(SRC_ROOT, "Train.csv")
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"Không tìm thấy {csv_path}\n"
            f"Hãy giải nén dataset vào thư mục: {SRC_ROOT}"
        )

    print("📂 Đọc Train.csv...")
    df = pd.read_csv(csv_path)
    print(f"   Tổng ảnh: {len(df)}")

    # Tính tọa độ YOLO (normalized 0–1)
    df["cx"] = (df["Roi.X1"] + df["Roi.X2"]) / 2 / df["Width"]
    df["cy"] = (df["Roi.Y1"] + df["Roi.Y2"]) / 2 / df["Height"]
    df["bw"] = (df["Roi.X2"] - df["Roi.X1"]) / df["Width"]
    df["bh"] = (df["Roi.Y2"] - df["Roi.Y1"]) / df["Height"]

    train_df, val_df = train_test_split(df, test_size=0.2, random_state=42)
    print(f"   Train: {len(train_df)} | Val: {len(val_df)}")

    for split in ["train", "val"]:
        os.makedirs(f"{OUT}/images/{split}", exist_ok=True)
        os.makedirs(f"{OUT}/labels/{split}", exist_ok=True)

    def write_split(dataframe, split):
        total = len(dataframe)
        for idx, (i, row) in enumerate(dataframe.iterrows()):
            if idx % 1000 == 0:
                print(f"   [{split}] {idx}/{total}...")
            src_img = os.path.join(SRC_ROOT, row["Path"].replace("/", os.sep))
            uid = f"{row['ClassId']:05d}_{i}"
            Image.open(src_img).save(f"{OUT}/images/{split}/{uid}.png")
            with open(f"{OUT}/labels/{split}/{uid}.txt", "w") as f:
                f.write(
                    f"{row['ClassId']} {row['cx']:.6f} {row['cy']:.6f} "
                    f"{row['bw']:.6f} {row['bh']:.6f}\n"
                )

    print("\n🔄 Convert train split...")
    write_split(train_df, "train")
    print("🔄 Convert val split...")
    write_split(val_df, "val")
    print("✅ Convert xong!\n")


def create_yaml():
    """Tạo file data.yaml cho Ultralytics."""
    data = {
        "path": os.path.abspath(OUT),
        "train": "images/train",
        "val":   "images/val",
        "nc":    43,
        "names": CLASS_NAMES,
    }
    with open(YAML_PATH, "w", encoding="utf-8") as f:
        yaml.dump(data, f, allow_unicode=True, sort_keys=False)
    print(f"✅ Tạo {YAML_PATH} xong!\n")


def train():
    """Train YOLOv8."""
    print(f"🚀 Bắt đầu train yolov8{MODEL_SIZE} | {EPOCHS} epochs | batch {BATCH}\n")
    model = YOLO(f"yolov8{MODEL_SIZE}.pt")
    model.train(
        data=YAML_PATH,
        epochs=EPOCHS,
        imgsz=IMGSZ,
        batch=BATCH,
        name="gtsrb_v1",
        project="./runs",
        patience=10,
        device=0,        # GPU 0; đổi thành 'cpu' nếu không có GPU
    )
    print("\n✅ Train xong! Weights lưu ở: ./runs/gtsrb_v1/weights/best.pt")


if __name__ == "__main__":
    # Bỏ qua convert nếu dataset đã tồn tại
    if not os.path.exists(f"{OUT}/images/train"):
        convert_dataset()
    else:
        print("⚡ Dataset đã convert, bỏ qua bước này.\n")

    if not os.path.exists(YAML_PATH):
        create_yaml()
    else:
        print(f"⚡ {YAML_PATH} đã tồn tại, bỏ qua.\n")

    train()
