"""
GTSRB YOLOv8 — Inference Script
Chạy: python predict.py --source <đường dẫn ảnh hoặc thư mục>
"""

import argparse
from ultralytics import YOLO

CLASS_NAMES = [
    "Speed limit (20)",     "Speed limit (30)",     "Speed limit (50)",
    "Speed limit (60)",     "Speed limit (70)",     "Speed limit (80)",
    "End speed limit (80)", "Speed limit (100)",    "Speed limit (120)",
    "No passing",           "No passing >3.5t",     "Right-of-way",
    "Priority road",        "Yield",                "Stop",
    "No vehicles",          "No vehicles >3.5t",    "No entry",
    "General caution",      "Dangerous curve left", "Dangerous curve right",
    "Double curve",         "Bumpy road",           "Slippery road",
    "Road narrows",         "Road work",            "Traffic signals",
    "Pedestrians",          "Children crossing",    "Bicycles crossing",
    "Beware ice/snow",      "Wild animals",         "End restrictions",
    "Turn right ahead",     "Turn left ahead",      "Ahead only",
    "Straight or right",    "Straight or left",     "Keep right",
    "Keep left",            "Roundabout",           "End no passing",
    "End no passing >3.5t",
]


def predict(source, weights, conf, show):
    model = YOLO(weights)
    results = model.predict(
        source=source,
        conf=conf,
        save=True,
        project="./runs",
        name="predict",
        show=show,
    )

    print("\n─── Kết quả ───")
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls)
            conf_score = float(box.conf)
            print(f"  [{cls_id:02d}] {CLASS_NAMES[cls_id]:<25} conf={conf_score:.2f}")

    print(f"\n✅ Ảnh kết quả lưu ở: ./runs/predict/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source",  default="./dataset/images/val",
                        help="Đường dẫn ảnh, thư mục, hoặc video")
    parser.add_argument("--weights", default="./runs/gtsrb_v1/weights/best.pt",
                        help="Đường dẫn file weights")
    parser.add_argument("--conf",    type=float, default=0.5,
                        help="Confidence threshold (0.0–1.0)")
    parser.add_argument("--show",    action="store_true",
                        help="Hiện ảnh kết quả ngay (cần GUI)")
    args = parser.parse_args()

    predict(args.source, args.weights, args.conf, args.show)
